/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum11;

/**
 *
 * @author rayfa
 */
public class MainPerpustakaan {
    public static void main(String[] args) {
        Perpustakaan perpustakaan = new Perpustakaan();

        Pengarang p1 = new Pengarang("Andrea Hirata");
        Pengarang p2 = new Pengarang("Ahmad Fuadi");
        Pengarang p3 = new Pengarang("James Clear");

        Buku b1 = new Buku("Laskar Pelangi", p1);
        Buku b2 = new Buku("Negeri 5 Menara", p2);
        Buku b3 = new Buku("Atomic Habits", p3);

        perpustakaan.tambahBuku(b1);
        perpustakaan.tambahBuku(b2);
        perpustakaan.tambahBuku(b3);

        perpustakaan.infoPerpustakaan();
    }
}

