/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author rayfa
 */
import java.util.List;

public class Barang {
    private int id;
    private int sellerId;
    private String title;
    private String description;
    private double initialPrice;
    private String category;
    private List<String> images;

    public void updateDetails() {
        // sementara kosong
    }

    public void archive() {
        // sementara kosong
    }
}
