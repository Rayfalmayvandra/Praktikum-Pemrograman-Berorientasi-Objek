/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;

/**
 *
 * @author rayfa
 */
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class Peminjaman implements Transaksi, Serializable {
    private Anggota anggota;
    private List<Buku> buku;
    private LocalDate tanggalPinjam;
    private LocalDate tanggalKembali;

    public Peminjaman(Anggota anggota, List<Buku> buku, LocalDate tanggalPinjam) {
        this.anggota = anggota;
        this.buku = buku;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalPinjam.plusDays(14);
    }

    @Override
    public void pinjam() {
        System.out.println("Peminjaman oleh: " + anggota.getNama());
        System.out.println("Tanggal pinjam: " + tanggalPinjam);
        System.out.println("Batas kembali: " + tanggalKembali);
        System.out.println("Daftar buku:");
        for (Buku b : buku) {
            b.tampil();
        }
    }

    @Override
    public void kembali() {
        System.out.println("Buku dikembalikan oleh " + anggota.getNama());
    }
}
