/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;

/**
 *
 * @author rayfa
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Perpustakaan implements Serializable {
    private List<Anggota> anggota = new ArrayList<>();
    private List<Buku> buku = new ArrayList<>();
    private List<Peminjaman> peminjaman = new ArrayList<>();

    public void tambahAnggota(Anggota a) {
        anggota.add(a);
    }

    public void tambahBuku(Buku b) {
        buku.add(b);
    }

    public void tambahPeminjaman(Peminjaman p) {
        peminjaman.add(p);
    }
}