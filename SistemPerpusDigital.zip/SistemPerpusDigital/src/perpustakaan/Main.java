/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;

/**
 *
 * @author rayfa
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println(">>================================<<");
        System.out.println(" SISTEM PERPUSTAKAAN DIGITAL ");
        System.out.println("<<================================>>");

        String idAnggota = inputAngka("ID Anggota: ");
        String nama = inputText("Nama Anggota: ");

        Anggota anggota = new Anggota(idAnggota, nama);

        int jumlahBuku = inputJumlah("Jumlah buku dipinjam: ");

        List<Buku> daftarBuku = new ArrayList<>();

        for (int i = 1; i <= jumlahBuku; i++) {
            System.out.println("Data buku ke-" + i);
            String idBuku = inputAngka("ID Buku: ");
            String judul = inputText("Judul Buku: ");
            String penulis = inputText("Penulis: ");
            daftarBuku.add(new Buku(idBuku, judul, penulis));
        }

        LocalDate tanggalPinjam = inputTanggal("Tanggal pinjam (YYYY-MM-DD): ");

        Peminjaman p = new Peminjaman(anggota, daftarBuku, tanggalPinjam);
        p.pinjam();

        Perpustakaan perpus = new Perpustakaan();
        perpus.tambahAnggota(anggota);
        for (Buku b : daftarBuku) {
            perpus.tambahBuku(b);
        }
        perpus.tambahPeminjaman(p);

        DataManager.simpan(perpus, "perpustakaan.ser");

        Perpustakaan baca =
                (Perpustakaan) DataManager.baca("perpustakaan.ser");

        if (baca != null) {
            System.out.println("Data berhasil dimuat ulang.");
        }

        System.out.println("><================================><");
        System.out.println("Program Telah Selesai.");
    }

    static String inputAngka(String label) {
        while (true) {
            System.out.print(label);
            String input = sc.nextLine();
            if (input.matches("\\d+")) {
                return input;
            }
            System.out.println("Input harus berupa angka.");
        }
    }

    static String inputText(String label) {
        while (true) {
            System.out.print(label);
            String input = sc.nextLine();
            if (!input.trim().isEmpty()) {
                return input;
            }
            System.out.println("Input tidak boleh kosong.");
        }
    }

    static int inputJumlah(String label) {
        while (true) {
            System.out.print(label);
            try {
                int val = Integer.parseInt(sc.nextLine());
                if (val > 0) return val;
            } catch (Exception ignored) {}
            System.out.println("Jumlah tidak valid.");
        }
    }

    static LocalDate inputTanggal(String label) {
        while (true) {
            System.out.print(label);
            try {
                return LocalDate.parse(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Format tanggal salah.");
            }
        }
    }
}

