/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum10;

/**
 *
 * @author rayfa
 */
public class MainPembayaran {
      public static void main(String[] args) {
        Elektronik laptop = new Elektronik();
        Makanan martabak = new Makanan();

        double hargaLaptop = 15000000;
        double hargaMartabak = 20000;

        double pajakLaptop = laptop.hitungpajak(hargaLaptop);
        double pajakMartabak = martabak.hitungpajak(hargaMartabak);

        System.out.println("=== Sistem Pembayaran Toko Assep ===");
        System.out.println("Harga Laptop: Rp " + hargaLaptop);
        System.out.println("Pajak Laptop (10%): Rp " + pajakLaptop);
        System.out.println("Total Bayar Laptop: Rp " + (hargaLaptop + pajakLaptop));
        System.out.println();
        System.out.println("Harga Martabak: Rp " + hargaMartabak);
        System.out.println("Pajak Martabak (5%): Rp " + pajakMartabak);
        System.out.println("Total Bayar Martabak: Rp " + (hargaMartabak + pajakMartabak));
    }
}

